function EphysClassification_analysis


%define parameters
tempPath = which('EphysClassification_analysis');
ind = regexp(tempPath, filesep);
params.currPath = tempPath(1:ind(end));
params.outputfileName = 'outputfile_ECA';

analysisTable = readtable([params.currPath 'EphysFeatureMatrix.xlsx']);
cellTypes = analysisTable.CellType;

%creating mean matrix
meanMat = table2array(analysisTable(:,2:5));


% remove rows in which all columns are empty
allNanRows = all(isnan(meanMat), 2);
meanMat(allNanRows,:) = [];

posAfterHyp = meanMat(:,3) > 0; %if After Hyperpolarization amplitude > 0 make it NaN
meanMat(posAfterHyp,4) = NaN;
zeroIsoRatio = meanMat(:,4)==0;%if Isolated spike fraction=0 make it NaN
meanMat(zeroIsoRatio,5) = NaN;


[m,std_sett] = mapstd(meanMat');
meanMat = m';
meanMatExt = meanMat;
fullRows = all(~isnan(meanMat), 2);
meanMatFull = meanMat(fullRows, :);

%constructing feature vector
for i=1:size(meanMat,1)
    if any(isnan(meanMat(i,:)))
        nanCol = find(isnan(meanMat(i,:)));
        nonNanCol = find(~isnan(meanMat(i,:)));
        meanMatWeight = meanMatFull(:, nonNanCol);
        weightVec = meanMatWeight*meanMat(i,nonNanCol)'./vecnorm(meanMatWeight')'/...
            norm(meanMat(i,nonNanCol));
        weightVec = (weightVec' + 1)/2;
        weightVec = weightVec/sum(weightVec);
        
        meanMatExt(i, nanCol) = weightVec*meanMatFull(:,nanCol);
    end
end


%generate dendogram
z = linkage(meanMatExt, 'ward');
[h,nodes,orig] = dendrogram(z,0); %plot dendogram


cellType=cellTypes(orig,1);
CellTypeLabel1=[];
CellTypeLabel2=[];
for i =1:length(cellType)
    if strcmp(cellType(i),'PN')
        CellTypeLabel1(end+1)=i;
    end
end
for i =1:length(cellType)
    if strcmp(cellType(i),'LN')
        CellTypeLabel2(end+1)=i;
    end
end

%Make first x axis for PNs
set(gca,'XTick',CellTypeLabel1','XTickLabel','','YTick',0:5:25,'YTickLabel',0:5:25,'tickdir','out','ticklabelinterpreter','none',...
    'FontSize',18,'Xcolor',[0 0.5 0]);
xtickangle(90);

%Make second x axis for LNs
ax1 = gca;
ax1_pos = ax1.Position;
ax2 = axes('Position', ax1_pos, 'XAxisLocation', 'bottom', 'YAxisLocation', 'left');
dendrogram(z,0);
set(gca,'XTick',CellTypeLabel2','XTickLabel',' ','YTick',0:5:25,'YTickLabel',0:5:25,'tickdir','out','ticklabelinterpreter','none',...
    'FontSize',18,'Xcolor','m');
xtickangle(90);
box off
set(gcf, 'PaperUnits', 'inches','PaperSize', [25,10]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0, 0, 25,10]);
set(gcf,'Position',[2 2 500 250]);

savefig([params.currPath  params.outputfileName '.fig']);
close all;


end
