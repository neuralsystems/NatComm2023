function Trajectory_analysis(params)

%define parameters
tempPath = which('Trajectory_analysis');
ind = regexp(tempPath, filesep);
params.currPath = tempPath(1:ind(end));
params.outputfileName = 'outputfile_TA';
params.binSize= 0.1;% set bin length for calculating peark firing rate
params.responseDuration = [0 6]; %set total record duration to be used for analysis
params.background = [0 2];
params.stimList={'1octen3ol10x01';'4methylcyclohexanol10x01';'6methyl5hepten2one10x01';'deet100x01';'llacticacid100x01';'dimethyltrisulfide10x01'};
params.stimAcronym={'1OCT3OL .01';'4MCYHOL .01';'6MHO .01';'DEET .1';'L-LA .1';'DM TS .01'};


inputfilepath_TA = [params.currPath 'inputfile_TA.mat'];
load(inputfilepath_TA);

uniqCells = unique(cellfun(@(x) x.cellName, outputs_binnedSpikes,'uniformoutput',false));
uniqStims = unique(cellfun(@(x) x.stimName, outputs_binnedSpikes,'uniformoutput',false));
numBins = round((params.responseDuration(2) - params.responseDuration(1))/params.binSize);
numCells = size(uniqCells,2);
numStims = size(uniqStims,2);
binsmat = zeros(numStims*numBins,numCells);
stimLab = cell(numStims*numBins, 1);
ind={};

for i=1:(length(uniqStims))
    for j=1:(height(params.stimList))
        if (strcmp(uniqStims(i),params.stimList{j,1}))
            OdorLabel{i}= params.stimAcronym{j,1};
            break;
        end
    end
    ind{end+1}=i;
end

for indrec=1:size(outputs_binnedSpikes,2)
    binnedSpikes = outputs_binnedSpikes{indrec}.binnedSpikes;
    binnedSpikes = binnedSpikes(1+params.responseDuration(1)/params.binSize:...
        params.responseDuration(2)/params.binSize) - ...
        mean(binnedSpikes(1+params.background(1)/params.binSize:...
        params.background(2)/params.binSize));
    stimind = find(ismember(uniqStims,outputs_binnedSpikes{indrec}.stimName));
    cellind = find(contains(uniqCells,outputs_binnedSpikes{indrec}.cellName));
    binsmat(1+(stimind-1)*numBins:stimind*numBins,cellind) = binnedSpikes;
    stimLab(1+(stimind-1)*numBins:stimind*numBins) = OdorLabel(stimind);
end


[coeff, score, latent] = pca(binsmat);

figure;

x = score(:,1);
y = score(:,2);
z = score(:,3);
g = gramm('x',x,'y',y,'z',z,'color',stimLab);

g.set_color_options('map','d3_10','lightness_range',[70 40],'chroma_range',[60 70],'legend','separate');
g.geom_line;
g.set_line_options('base_size',0.7)
g.set_names('x','PC1','y','PC2','z','PC3','color','Odors');

%for putting labels at 3s and 4s (every 30th and 40th bin)
timepoint = [30,40,90,100,150,160,210,220,270,280,330,340];
g.update('x',x(timepoint),'y',y(timepoint),'z',z(timepoint))
g.geom_point
g.set_point_options('base_size',2)
g.draw

labelArray = arrayfun(@(x) num2str(x), (1:numBins)*params.binSize, 'UniformOutput', false);
RemoveLabel = find(contains(labelArray, {'.','1','2','5','6'}));
labelArray(RemoveLabel) = {' '};

labelArray = repmat(labelArray', numStims, 1);
g.update('x',x+1,'y',y+1,'z',z+1, 'label', labelArray, 'color',stimLab);
g.geom_label3('FontSize', 10);
g.set_layout_options('legend', false);
g.set_text_options('label_scaling', 2)
g.draw

set(gcf, 'PaperUnits', 'inches','PaperSize', [6,4.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0, 0, 6,4.5]);
savefig([params.currPath params.outputfileName '.fig']);

close all;
end
